export class FicheTechnique {
    id_fiche!: number;
    fichier?: File ;
    nom_fiche!: string;
    type_plat!: string;
  
  }
  