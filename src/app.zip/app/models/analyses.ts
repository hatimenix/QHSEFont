export class Analyses {
    cause !: string;
    probabilite !: number;
    frequences !: number;
    severite !: number;
    niveau_risque !: number;
    arbe_cause !: string;
    danger_name !: string[];
    danger_lie !: number[];
    evenement !: number;
}
