export class Utilsateur {
    id !: number;
    compte !: string;
    nom !: string;
    courrier !: string;
    presente_vous !: string;
    image !: string;
    numero_tel !: string;
    fonction !: string;
    adresse_sip !: string;
    othermail !: string;
}
