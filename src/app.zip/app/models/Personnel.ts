export class Personnel {
    id! : number;
    compte!: string;
    nom!: string;
    courrier!: string;
    numero_tel!: string;
    presente_vous!: string;
    image?: File;
    fonction!: string;
    adresse_sip!: string;
    othermail!: string;
  
  }