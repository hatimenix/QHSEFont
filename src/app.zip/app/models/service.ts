export class Service {
    id !: number;
    service_nom !: string;
}
