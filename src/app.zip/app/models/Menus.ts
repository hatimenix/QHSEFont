export class Menus{
    id!: number;
    mois_concerne!:string;
    menus_generaux?: File ;
    menus_dessert?: File ;
    menu_s1?: File ;
    menu_s2?: File ;
    menu_s3?: File ;
    menu_s4?: File ;
    menu_s5?: File ;
    site !: number;
    site_name!:string;
   }
