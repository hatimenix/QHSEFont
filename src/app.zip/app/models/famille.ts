export class Famille {
    id !: number;
    famille_nom !: string;
    
}
