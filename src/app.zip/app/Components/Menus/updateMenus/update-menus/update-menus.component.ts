import { Component } from '@angular/core';

@Component({
  selector: 'app-update-menus',
  templateUrl: './update-menus.component.html',
  styleUrls: ['./update-menus.component.css']
})
export class UpdateMenusComponent {

}
